package com.latenightchauffeurs.Utils;

public interface IonAppListners {
    void isAppOpen();
}

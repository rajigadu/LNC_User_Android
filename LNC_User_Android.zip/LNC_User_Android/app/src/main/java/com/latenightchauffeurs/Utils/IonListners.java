package com.latenightchauffeurs.Utils;

public interface IonListners {
    void getDistanceTime(String result);
}
